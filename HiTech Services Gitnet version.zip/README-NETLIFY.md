# Hitech Services website — GitHub + Netlify

This project uses TanStack Start, React, Vite, and TypeScript. It is configured for Netlify SSR deployment using `@netlify/vite-plugin-tanstack-start`.

## Deploy from GitHub

1. Extract this project ZIP. The folder containing this README also contains `package.json`, `vite.config.ts`, and `netlify.toml`.
2. Create a new empty repository on GitHub.
3. Upload/push the CONTENTS of this folder to the repository root (not a nested `app/app` folder). Include the `packages/` workspace folder. Do not upload `node_modules` or `dist`.
4. In Netlify, choose **Add new project → Import an existing project**, connect GitHub, and select the repository.
5. Set the base directory to blank / repository root. Netlify should read `netlify.toml`; build command is `bun run build:netlify`, publish directory is `dist/client`.
6. Deploy. Future pushes to the selected branch trigger new deployments.

## Run locally

Install Bun (and Node.js 22 or newer), then from this folder run:

```bash
npm install
npm run dev
```

Production build check:

```bash
npm run build
```

## Notes

- `netlify.toml` is already set up. Do not change the publish directory to the repository root.
- Keep workspace packages in `packages/`; they are referenced by `package.json`.
- The enquiry form is configured for WhatsApp handoff, not server-side email delivery.
- Add future secrets in Netlify environment variables, not in source files.
