import type { ScrollScrubScene, ScrollScrubTheme } from "@/components/scroll-scrub/scroll-scrub";
export const scrollScrubTheme: ScrollScrubTheme = { accent: "#2DD4BF", background: "#F7F9FB", ink: "#0B2545", muted: "#64748B" };
export const scrollScrubScenes: ScrollScrubScene[] = [{ id:"home", label:"Home", poster:"/assets/world/scene-01-poster.png", clip:"/assets/world/scene-01.mp4", title:"Comfort, safety and thoughtful details.", body:"Explore window and home solutions tailored to your space.", kicker:"HITECH SERVICES", tags:["Hyderabad","Made to measure"] }];
